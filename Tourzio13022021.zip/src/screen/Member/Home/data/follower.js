const Entry = [
    {
        image: 'https://images.unsplash.com/photo-1503185912284-5271ff81b9a8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80',
        name: 'Audrey Tautou',
        name_ar: 'أودري توتو',
        place: 'Marseille, France',
        place_ar: 'مرسيليا ، فرنسا',
    },
    {
        image: 'https://images.unsplash.com/photo-1506919258185-6078bba55d2a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=815&q=80',
        name: 'George Clooney',
        name_ar: 'جورج كلوني',
        place: 'Florence, italy',
        place_ar: 'فلورنسا، إيطاليا',
    },
    {
        image: 'https://images.unsplash.com/photo-1543084951-1650d1468e2d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80',
        name: 'Nicholas George',
        name_ar: 'نيكولاس جورج',
        place: 'Florence, italy',
        place_ar: 'فلورنسا، إيطاليا',
    },

    {
        image: 'https://images.unsplash.com/photo-1484515991647-c5760fcecfc7?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=687&q=80',
        name: 'David Richard',
        name_ar: 'ديفيد ريتشارد',
        place: 'Barcelona, Spain',
        place_ar: 'برشلونة، إسبانيا',
    },
    {
        image: 'https://images.unsplash.com/photo-1464863979621-258859e62245?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=633&q=80',
        name: 'Catherine Zeta',
        name_ar: 'كاثرين زيتا',
        place: 'New York, USA',
        place_ar: 'نيويورك ، الولايات المتحدة الأمريكية',
    },
    {
        image: 'https://images.unsplash.com/photo-1557555187-23d685287bc3?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=700&q=80',
        name: 'Scarlett Johansson',
        name_ar: 'سكارلت جوهانسون',
        place: 'Las Vegas, USA',
        place_ar: 'لاس فيغاس ، الولايات المتحدة الأمريكية',
    },
    {
        image: 'https://images.unsplash.com/photo-1562003389-902303a38425?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1429&q=80',
        name: 'Anna Chipovskaya',
        name_ar: 'آنا تشيبوفسكايا',
        place: 'Moscow, Russia',
        place_ar: 'موسكو، روسيا',
    },
]

export default Entry