const Entry = [

    {
        image: 'https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80',
        desc: 'Thailand',
        desc_ar:'تايلاند',
        price:'$2400/-'
    },
    {
        image: 'https://images.unsplash.com/photo-1460891053196-b9d4d9483d9b?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1375&q=80',
        desc: 'Switzerland',
        desc_ar:'سويسرا',
        price:'$3800/-'
    },
    {
        image: 'https://images.unsplash.com/photo-1511047155551-84140e1cf6a6?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60',
        desc: 'Turkey',
        desc_ar:'ديك رومي',
        price:'$2100/-'
    },
    {
        image: 'https://images.unsplash.com/photo-1513073945753-eb763d2a99de?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1267&q=80',
        desc: 'Italy',
        desc_ar:'إيطاليا',
        price:'$3100/-'
    },
    {
        image: 'https://images.unsplash.com/photo-1464797545438-4657f7abb2f6?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1487&q=80',
        desc: 'Elepahant Island',
        desc_ar:'جزيرة الفيل',
        price:'$3050/-'
    },
   
]

export default Entry