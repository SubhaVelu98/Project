const Entry = [

  {
      image: 'https://images.unsplash.com/photo-1517094629229-f5e0c2f88440?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80',
      desc: 'Alaska',
      desc_ar:'ألاسكا',
      price:'$5300/-'
  },
  {
      image: 'https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1266&q=80',
      desc: 'Africa',
      desc_ar:'أفريقيا',
      price:'$4250/-'
  },
  {
      image: 'http://7tripson.com/images/landmarks/australia_uluru_big.jpg',
      desc: 'Australia',
      desc_ar:'أستراليا',
      price:'$3500/-'
  },
  {
      image: 'https://images.unsplash.com/photo-1560356016-c58a8dfd16db?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1400&q=80',
      desc: 'Romania',
      desc_ar:'رومانيا',
      price:'$3100/-'
  },
  {
      image: 'https://images.unsplash.com/photo-1548375746-b97985599a3e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80',
      desc: 'Algeria',
      desc_ar:'الجزائر',
      price:'$3250/-'
  },
 
]

export default Entry