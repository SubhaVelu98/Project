const Entry = [

    {
        image: 'https://images.unsplash.com/photo-1534008897995-27a23e859048?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1268&q=80',
        desc: 'Thailand',
        desc_ar:'تايلاند',
        price:'$1400/-'
    },
    {
        image: 'https://images.unsplash.com/photo-1498503403619-e39e4ff390fe?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1950&q=80',
        desc: 'Greece',
        desc_ar:'اليونان',
        price:'$6020/-'
    },
    {
        image: 'https://images.unsplash.com/photo-1543906965-f9520aa2ed8a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80',
        desc: 'Romania',
        desc_ar:'رومانيا',
        price:'$3100/-'
    },
    {
        image: 'https://images.unsplash.com/photo-1500817904307-e664893dcbab?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80',
        desc: 'Switzerland',
        desc_ar:'سويسرا',
        price:'$2100/-'
    },
    {
        image: 'https://images.unsplash.com/photo-1541321814039-dc8c3e3a07cb?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1471&q=80',
        desc: 'Italy',
        desc_ar:'إيطاليا',
        price:'$3050/-'
    },
    {
        image: 'https://images.unsplash.com/photo-1540211159693-9c5c1a8d0666?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=685&q=80',
        desc: 'Turkey',
        desc_ar:'ديك رومى',
        price:'$3500/-'
    },
]

export default Entry