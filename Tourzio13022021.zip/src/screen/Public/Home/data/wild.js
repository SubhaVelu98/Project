const Entry = [

  {
      image: 'https://images.unsplash.com/photo-1509588059631-cd16608b9e6a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1216&q=80',
      desc: 'Africa',
      desc_ar:'أفريقيا',
      price:'$2400/-'
  },
  {
      image: 'https://images.unsplash.com/photo-1507461476191-0ed4f9f18533?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80',
      desc: 'India',
      desc_ar:'الهند',
      price:'$3800/-'
  },
  {
      image: 'https://images.unsplash.com/photo-1515444347446-4380c4d8a6ed?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1951&q=80',
      desc: 'Amazon',
      desc_ar:'أمازون',
      price:'$2100/-'
  },
  {
      image: 'https://images.unsplash.com/photo-1508977718187-33491c4a6f3f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1381&q=80',
      desc: 'Alaska',
      desc_ar:'ألاسكا',
      price:'$3100/-'
  },
  {
      image: 'https://images.unsplash.com/photo-1529451310546-178d75816ffc?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=622&q=80',
      desc: 'Australia',
      desc_ar:'أستراليا',
      price:'$3050/-'
  },
 
]

export default Entry