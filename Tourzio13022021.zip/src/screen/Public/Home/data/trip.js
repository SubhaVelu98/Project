const Entry = [

    {
        image: 'https://images.unsplash.com/photo-1494774157365-9e04c6720e47?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60',
        desc: 'HoneyMoon',
        desc_ar:'شهر العسل',
    },
    {
        image: 'https://images.unsplash.com/photo-1527618956224-702fcb42217b?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80',
        desc: 'Adventure',
        desc_ar:'مغامرة',
    },
    {
        image: 'https://images.unsplash.com/photo-1433086966358-54859d0ed716?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80',
        desc: 'Nature',
        desc_ar:'طبيعة',
    },
    {
        image: 'https://images.unsplash.com/photo-1561525140-c2a4cc68e4bd?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80',
        desc: 'Family',
        desc_ar:'أسرة',
    },
    {
        image: 'https://images.unsplash.com/photo-1549480017-d76466a4b7e8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1338&q=80',
        desc: 'Wildlife',
        desc_ar:'الحيوانات البرية',
    },
    {
        image: 'https://images.unsplash.com/photo-1502998732392-615e9b445fa4?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80',
        desc: 'WaterWorld',
        desc_ar:'عالم الماء',
    },
]

export default Entry