const Entry = [

    {
        image: 'https://images.unsplash.com/photo-1559582865-775a8d1aa21c?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1184&q=80',
        reviewer: 'Nicolas Cage',
        reviewer_ar:'نيكولاس كيج',
        place: 'New York, USA',
        place_ar:'نيويورك ، الولايات المتحدة الأمريكية',
        posted: '6 hrs ago',
        posted_ar:'قبل 6 ساعات',
        reviewMsg: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin facilisis metus.',
    },
    {
        image: 'https://images.unsplash.com/photo-1504276048855-f3d60e69632f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80',
        reviewer: 'Ana Nicola',
        reviewer_ar:'آنا نقولا',
        place: 'Florida, USA',
        place_ar:'فلوريدا ، الولايات المتحدة الأمريكية',
        posted: '1 day ago',
        posted_ar:'قبل 1 ساعات',
        reviewMsg: 'Nullam eros dolor, consequat a tempor et, at libero. Aliquam erat volutpat.',
    },
    {
        image: 'https://images.unsplash.com/photo-1535440568529-40a78746670d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80',
        reviewer: 'Nicolas Cage',
        reviewer_ar:'نيكولاس كيج',
        place: 'New York, USA',
        place_ar:'نيويورك ، الولايات المتحدة الأمريكية',
        posted: '6 hrs ago',
        posted_ar:'قبل 6 ساعات',
        reviewMsg: 'Lorem ipsum dolor sit amet, consectetur elit. Proin facilisis facilisis metus.',
    },
    {
        image: 'https://images.unsplash.com/photo-1484328861630-cf73b7d34ea3?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1352&q=80',
        reviewer: 'Ana Nicola',
        reviewer_ar:'آنا نقولا',
        place: 'Florida, USA',
        place_ar:'فلوريدا ، الولايات المتحدة الأمريكية',
        posted: '1 day ago',
        posted_ar:'قبل 1 ساعات',
        reviewMsg: 'Nullam eros dolor, a tempor et, tincidunt at libero. Aliquam erat volutpat.',
    },

]

export default Entry