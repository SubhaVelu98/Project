const Entry = [

    {
      price: 'Below $500'
    },
    {
      price: '$500 - $1000'
    },
    {
      price: '$1000 - $2000'
    },
    {
      price: '$2000 - $4000'
    },
    {
      price: '$4000 - $6000'
    },
    {
      price: '$6000 - $8000'
    },
    {
      price: '$8000 - $10000'
    },
    {
      price: '$10000+'
    }
  ]
  
  export default Entry
  