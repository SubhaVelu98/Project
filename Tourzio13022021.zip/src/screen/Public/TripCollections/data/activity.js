const Entry = [

    {
      limit: 'Nature',
      limit_ar:'طبيعة',
      limitNos: 'Beach',
      limitNos_ar:'شاطئ بحر',
    },
    {
      limit: 'Historical',
      limit_ar:'تاريخي',
      limitNos: 'Religious',
      limitNos_ar:'متدين',
    }
  
  ]
  
  export default Entry
  