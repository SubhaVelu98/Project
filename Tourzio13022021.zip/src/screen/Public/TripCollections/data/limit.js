const Entry = [

    {
      limit: '1-3',
      limitNos: '4-6'
    },
    {
      limit: '7-9',
      limitNos: '10-12'
    }
  
  ]
  
  export default Entry
  