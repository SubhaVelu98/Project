const Entry = [

    {
        image: require('@asset/images/air-freight.png'),
        desc: 'By Air',
        desc_ar:'عن طريق الجو',
    },
    {
        image: require('@asset/images/train.png'),
        desc: 'By Train',
        desc_ar:'بالقطار',
    },
    {
        image: require('@asset/images/cruise.png'),
        desc: 'By Cruise',
        desc_ar:'بواسطة كروز',
    },
]

export default Entry