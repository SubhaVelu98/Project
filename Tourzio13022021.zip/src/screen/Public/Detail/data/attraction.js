const Entry = [

    {
        image: 'https://images.unsplash.com/photo-1534008897995-27a23e859048?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1268&q=80',
        desc: 'Larissa',
        desc_ar:'لاريسا',
    },
    {
        image: 'https://images.unsplash.com/photo-1540393941896-255c66854aaa?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80',
        desc: 'Piraeus',
        desc_ar:'بيرايوس',
    },
    {
        image: 'https://images.unsplash.com/photo-1498503182468-3b51cbb6cb24?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80',
        desc: 'Loannina',
        desc_ar:'لونينا',
    },
    {
        image: 'https://images.unsplash.com/photo-1498475413310-5ee4dda94b0c?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80',
        desc: 'Meteora',
        desc_ar:'ميتيورا',
    },
    {
        image: 'https://images.unsplash.com/photo-1554840757-8ceb09d6aa05?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80',
        desc: 'Mykonos',
        desc_ar:'ميكونوس',
    },
]

export default Entry