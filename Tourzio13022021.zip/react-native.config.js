module.exports = {
    "assets": [
        "./assets/fonts",
        "./node_modules/native-base/Fonts"
    ]
};