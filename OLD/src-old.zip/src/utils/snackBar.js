import Snackbar from 'react-native-snackbar';
import {Colors} from '../theme';
export const SnackBarMessage = (message, slug = '') => {
  Snackbar.show({
    text: message,
    duration: Snackbar.LENGTH_LONG,
    numberOfLines: 5,
    backgroundColor:
      slug === 'error'
        ? Colors.error
        : slug === 'success'
        ? Colors.success
        : Colors.purple,
  });
};
