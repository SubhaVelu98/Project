import Home from './home';
import Example from './example';
import setpin from './setpin';
import recovery from './recovery';
import recoveryphrase from './recoveryphrase';
import restore from './restore';
import confirmpin from './confirmpin';
import Patners from './Patners';

export {Home, Example, setpin,recovery,recoveryphrase,restore,confirmpin,Patners};
