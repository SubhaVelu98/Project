import Register from './register';

export {Register};
