export const SCREEN_CONSTANT = {
  REGISTER: 'register',
  HOME: 'home',
  EXAMPLE: 'example',
  SETPIN: 'setpin',
  RECOVERY: 'recovery',
  RECOVERYPHRASE: 'recoveryphrase',
  RESTORE: 'restore',
  CONFIRMPIN: 'confirmpin',
  PATNERS: 'Patners'

};
