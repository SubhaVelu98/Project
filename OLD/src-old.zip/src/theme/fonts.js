export const size = {
  small: 10,
  medium: 15,
  large: 18,
  extraLarge: 20,
};

export const lineHeight = {
  small: 10,
  medium: 15,
  large: 18,
  extraLarge: 20,
};
