export default {
  Montserrat: "Montserrat-Regular",
  MontserratBold: "Montserrat-Bold",
  MontserratMedium: "Montserrat-Medium",
  MontserratSemiBold: "Montserrat-SemiBold"
};
