export default {
  white: "#fff",
  error: "#FF9494",
  success: "rgba(92,184,92,0.7)",
  purple: "#1E295A",
  grey: "#333333",
  greyOpcity70: "rgba(51, 51, 51, 0.7)",
};
