export default {
  background: require("../images/background.jpg"),
  dbxLogo: require("../images/dbxLogo.png"),
};
