import Colors from "./color";
import * as Fonts from "./fonts";
import Images from "./images";
import FontFamily from "./fontsFamily";

export { Colors, Fonts, Images, FontFamily };
