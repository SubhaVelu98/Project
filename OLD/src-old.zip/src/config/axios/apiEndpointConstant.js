export const TODOS = "todos";
export const REGISTER = "register";
