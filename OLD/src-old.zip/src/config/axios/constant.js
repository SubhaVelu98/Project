export default {
  devURL: "https://mobile-api-dbx-dev.devtomaster.com/v1/",
  timeout: 30000,
  applicationJsonHeader: {
    accept: "application/json",
    "Content-Type": "application/json",
  },
};
